const router = require('express').Router()

router.get('/login', (req,res)=>{
    res.render('auth/login',{
        title: "Login"
    })
})

router.get('/registration', (req,res)=>{
    res.render('auth/registration',{
        title: "Registration"
    
    })
    
})

module.exports = router;