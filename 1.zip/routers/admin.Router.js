const router = require('express').Router();

router.get('/', (req,res)=>{
    res.render('home',{
        title:'Dashboard withour Login'
    })
})

router.post('/', (req,res)=>{

    res.render('home',{
        title:'Dashboard'
    })
})

module.exports= router;