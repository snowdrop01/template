const express = require('express')
const bodyParser = require('body-parser')
const path = require('path')

const app = express();

app.set('view engine','ejs');
app.set('views', 'views') 

app.use(bodyParser.urlencoded({extended:true})) 
app.use(express.static(path.join(__dirname, 'public'))) //public

app.use('/auth', require('./routers/auth.Router'))
app.use('/', require('./routers/admin.Router'))

app.use((req,res)=>{
    res.send("404")
})

app.listen(4000,()=>{
    console.log(`server is running at http://localhost:4000`);
})